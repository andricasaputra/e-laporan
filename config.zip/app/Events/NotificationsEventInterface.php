<?php

namespace App\Events;

interface NotificationsEventInterface
{

}