<?php

namespace App\Models\Operasional;

interface ModelOperasionalInterface
{
	public function getBulanAttribute($value);
}