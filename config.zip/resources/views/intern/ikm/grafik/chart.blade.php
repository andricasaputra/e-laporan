<div class="clearfix"></div>

<div class="col-md-6 col-sm-12 col-xs-12">
	<div class="x_panel">
	  <div class="x_content">
	  	<div id="rata-rata"></div>
	  </div>
	</div>
</div>

<div class="col-md-6 col-sm-12 col-xs-12">
	<div class="x_panel">
	  <div class="x_content">
	  	<div id="jenis_kelamin"></div>
	  </div>
	</div>
</div>

<div class="clearfix"></div>

<div class="col-md-4 col-sm-12 col-xs-12">
	<div class="x_panel">
	  <div class="x_content">
	  	<div id="umur"></div>
	  </div>
	</div>
</div>

<div class="col-md-4 col-sm-12 col-xs-12">
	<div class="x_panel">
	  <div class="x_content">
	  	<div id="pendidikan"></div>
	  </div>
	</div>
</div>

<div class="col-md-4 col-sm-12 col-xs-12">
	<div class="x_panel">
	  <div class="x_content">
	  	<div class="row">
	  		<div id="pekerjaan"></div>
	  	</div>
	  </div>
	</div>
</div>
