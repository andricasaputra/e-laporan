<?php if($is_open === null): ?>

<script>
  window.location = '<?php echo e(route('ikm.closed')); ?>';
</script>

<?php exit; ?>

<?php endif; ?>



<?php $__env->startSection('link'); ?>

<link href="<?php echo e(asset('css/swiper.min.css')); ?>" rel="stylesheet">

<link href="<?php echo e(asset('css/ikm.css')); ?>" rel="stylesheet">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <?php echo $__env->make('inc.ikm_navbar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <?php use App\Http\Controllers\TanggalController as Tanggal; ?>
  <!--==========================
    Intro Section
  ============================-->
  <section id="survey">

    <!-- Swiper -->
    <form id="formsubmit">

      <?php echo csrf_field(); ?>

      <div class="container-fluid text-center form">
        <div class="swiper-container">

          <div class="col-12 text-center mt-5" style="margin-bottom: 5%">
            <h5 class="judul"><?php echo e($is_open->keterangan); ?></h5>
            <p class="judul"><?php echo e(Tanggal::tanggalIndo($is_open->start_date)); ?> s/d <?php echo e(Tanggal::tanggalIndo($is_open->end_date)); ?></p>
            <hr>
            <div id="message"></div>
          </div>
          
          <div class="swiper-wrapper">  
            
            <div class="swiper-slide">
              <div class="container">
                <h5 class="mb-5 survey-questions">Data Responden</h5>
                <p class="sub"><small>Silahkan lengkapi data dibawah ini!</small></p>
                
                <div class="survey-responden">
                    <div class="form-group">
                      <select class="form-control" name="jenis_layanan" id="jenis_layanan" required="required">
                        <option disabled selected value="">- Jenis Layanan -</option>
                        <?php $__currentLoopData = $layanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                          <option value="<?php echo e($l->id); ?>"><?php echo e($l->jenis_layanan); ?></option>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                    <div class="form-row">
                      <div class="form-group col-md-6"> 
                        <select class="form-control" name="jenis_kelamin" id="jenis_kelamin" required="required">
                          <option disabled selected value="">- Jenis Kelamin -</option>
                          <option value="1">Laki-laki</option>
                          <option value="2">Perempuan</option>
                        </select>
                      </div>
                      <div class="form-group col-md-6">
                        <select class="form-control" name="umur" id="umur" required="required">
                          <option disabled selected value="">- Umur -</option>
                          <?php $__currentLoopData = $umur; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <option value="<?php echo e($u->id); ?>"><?php echo e($u->umur); ?></option>

                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div>
                    </div>
                    <div class="form-row">
                      <div class="form-group col-md-6">
                        <select class="form-control" name="pendidikan" id="pendidikan" required="required">
                          <option disabled selected value="">- Pendidikan Terakhir -</option>
                          <?php $__currentLoopData = $pendidikan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <option value="<?php echo e($p->id); ?>"><?php echo e($p->pendidikan); ?></option>

                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div>
                      <div class="form-group col-md-6">
                        <select class="form-control" name="pekerjaan" id="pekerjaan" required>
                          <option disabled selected value="">- Pekerjaan -</option>
                            <?php $__currentLoopData = $pekerjaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                              <option value="<?php echo e($p->id); ?>"><?php echo e($p->pekerjaan); ?></option>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div>
                    </div>
                </div>
                
              </div>
            </div>

            <input type="hidden" name="ikm_id" value="<?php echo e($is_open->id); ?>">

            <?php $no = 1 ?>

            <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="swiper-slide uncheck">
              <div class="continer">
              <h5 class="mb-5 survey-questions">Pendapat responden tentang pelayanan</h5>
              <p class="sub"><small>Silahkan pilih jawaban yang paling sesuai!</small></p>
              <div class="col-12">
                <input type="hidden" name="ikm_id" value="<?php echo e($is_open->id); ?>">
                    <div class="form-group mt-3 mb-3">
                      <div class="mb-3 survey-questions">
                        <h5><?php echo e($no++); ?>. <?php echo e($question->question); ?></h5>
                        <?php $__currentLoopData = $question->answer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <div class="form-check form-check-inline cek-form " style="margin-top: 20px;margin-bottom: 20px">
                            <div class="radio">
                              <label>
                                <input  type="radio" value="<?php echo e($answer->id); ?>" name="<?php echo e($question->id); ?>[]">
                                <?php echo e($answer->answer); ?>

                              </label>
                            </div>
                          </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </div>  
                    </div>
                </div> 
                <?php if(count($questions) == $no - 1): ?>
                  <div class="text-center"><button type="submit" class="mt-5 send_ikm">Kirim</button></div>
                  <br>
                <?php endif; ?>
              </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>

          <div id="counter"></div>
          <!-- Add Pagination -->
          <div class="swiper-pagination"></div>
          <!-- Add Arrows -->
          <div class="swiper-button-next">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 27 44"><path d="M27,22L27,22L5,44l-2.1-2.1L22.8,22L2.9,2.1L5,0L27,22L27,22z"></svg>
          </div>
          <div class="swiper-button-prev">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 27 44"><path d="M0,22L22,0l2.1,2.1L4.2,22l19.9,19.9L22,44L0,22L0,22L0,22z"></svg>
          </div>
        </div>
      </div>
    </form>
    <hr>
  </section><!-- #intro -->

  <main>
  <!--==========================
      Contact Section
    ============================-->
    <section id="contact">
      <div class="container">
        <div class="section-header">
          <h2>Kontak kami</h2>
          <p>Jika anda memiliki keluhan, saran atau masukan atas pelayanan yang kami berikan,
            silahkan hubungi kami melalui call center dibawah ini. Kami informasikan bahwa petugas kami
            <b>tidak</b> menerima <b>suap</b> dan <b>gratifikasi</b> dalam bentuk apapun!
          </p>
        </div>

        <div class="row contact-info">

          <div class="col-md-4">
            <div class="contact-address">
              <i class="ion-ios-location-outline"></i>
              <h3>Alamat</h3>
              <address>Jln. Pelabuhan Badas No. 01 Sumbawa Besar</address>
            </div>
          </div>

          <div class="col-md-4">
            <div class="contact-phone">
              <i class="ion-ios-telephone-outline"></i>
              <h3>Telepon</h3>
              <p><a href="tel:+155895548855">(0371) 2629152</a></p>
            </div>
          </div>

          <div class="col-md-4">
            <div class="contact-email">
              <i class="ion-ios-email-outline"></i>
              <h3>Email</h3>
              <p><a href="#">humasskpsumbawa@gmail.com</a></p>
            </div>
          </div>

        </div>
      </div>

    </section><!-- #contact -->

  </main>

<?php $__env->stopSection(); ?>	

<?php $__env->startSection('script'); ?>

<script src="<?php echo e(asset('js/swiper.min.js')); ?>"></script>

<script src="<?php echo e(asset('js/ikm.js')); ?>"></script>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>