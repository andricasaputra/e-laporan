<?php $__env->startSection('title', 'Menu Operasional KT'); ?>

<?php $__env->startSection('barside'); ?>

  <?php echo $__env->make('intern.inc.barside', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
  <div class="col-md-4 col-sm-12">
    <div class="card text-center">
      <div class="card-body">
        <i class="fa fa-chart-line fa-3x"></i>
        <h4 class="card-text pull-right">
          Data Operasional
        </h4>
      </div>
    </div>
  </div>  
  <div class="col-md-4 col-sm-12">
    <div class="card text-center">
      <div class="card-body">
        <h4 class="card-text pull-right">
          Upload Laporan Operasional
        </h4>
      </div>
    </div>
  </div> 
  <div class="col-md-4 col-sm-12">
    <div class="card text-center">
      <div class="card-body">
        <h4 class="card-text pull-right">
          Donwload Laporan Operasional
        </h4>
      </div>
    </div>
  </div> 
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('intern.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>