<?php $__env->startSection('title', 'Home Operasional - Halaman Utama'); ?>

<?php $__env->startSection('barside'); ?>

  <?php echo $__env->make('intern.inc.barside', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<style type="text/css">
  .card {
    width: 100%;
    margin-bottom: 5%;
    border: 1px solid #eaeaea;
  }
</style>

<?php use App\Http\Controllers\TanggalController as Tanggal; ?>



    <?php if($datas['bulan'] !== null): ?>
       <h3>Ringkasan Data Operasional Bulan <?php echo e(Tanggal::bulan($datas['bulan'])); ?> Tahun <?php echo e($datas['tahun']); ?></h3>
    <?php else: ?>
      <h3>Ringkasan Data Operasional Tahun <?php echo e($datas['tahun']); ?></h3>
    <?php endif; ?>

    <form id="change_data">
      <div class="row mb-3">
          <div class="col-6">
            <label for="year">Pilih Tahun</label>
            <select class="form-control" name="year" id="year">
              <?php for($i = date('Y') - 3; $i < date('Y') + 2 ; $i++): ?>
          
                <?php if($i == $datas['tahun']): ?>

                  <option value="<?php echo e($i); ?>" selected><?php echo e($i); ?></option>

                <?php else: ?>

                  <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>

                <?php endif; ?>

              <?php endfor; ?>
            </select>
          </div>

          <div class="col-6">
            <label for="month">Pilih Bulan</label>
            <select class="form-control" name="month" id="month">
              <option value="">Semua</option>
              <?php for($i = 1; $i < 13 ; $i++): ?>
          
                <?php if($i == $datas['bulan']): ?>

                  <option value="<?php echo e($i); ?>" selected><?php echo e(Tanggal::bulan($i)); ?></option>

                <?php else: ?>

                  <option value="<?php echo e($i); ?>"><?php echo e(Tanggal::bulan($i)); ?></option>

                <?php endif; ?>

              <?php endfor; ?>
              
            </select>
          </div>
          <div class="col-4 mt-3">
             <button type="submit" class="btn btn-danger">Pilih</button>
            </div>
          </div>
    </form>

    <div class="row">
      <?php $__currentLoopData = $datas['kh']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-sm-3">
          <div class="card">
            <div class="card-body">
              <div class="row">
                <div class="col-sm-12 card_body">
                    <h4 class="card-title"><?php echo e($key); ?></h4>
                    <small><i>Berdasarkan Sertifikasi</i></small>
                    <h5 class="card-text"><i>Frekuensi : <?php echo e($data['frekuensi']); ?></i></h5>
                    <a href="<?php echo e($data['link']); ?>" class="btn btn-primary">Detail</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="row">
      <?php $__currentLoopData = $datas['kt']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-sm-3">
          <div class="card">
            <div class="card-body">
              <div class="row">
                <div class="col-sm-12 card_body_welcome">
                    <h4 class="card-title"><?php echo e($key); ?></h4>
                    <small><i>Berdasarkan Sertifikasi</i></small>
                    <h5 class="card-text"><i>Frekuensi : <?php echo e($data['frekuensi']); ?></i></h5>
                    <a href="<?php echo e($data['link']); ?>" class="btn btn-success">Detail</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="row">
      <?php $__currentLoopData = $datas['pnbp']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-sm-3">
          <div class="card">
            <div class="card-body">
              <div class="row">
                <div class="col-sm-12 card_body_welcome">
                    <h4 class="card-title"><?php echo e($key); ?></h4>
                    <small><i>Berdasarkan Sertifikasi</i></small>
                    <h5 class="card-text"><i>Total : <?php echo e($data); ?></i></h5>
                </div>
              </div>
            </div>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script>
  $(document).ready(function(){

    $('#change_data').on('submit', function(e){

      e.preventDefault();

      let year = $('#year').val();

      let month = $('#month').val();

      if (year != '' && month == '') {

        window.location = '<?php echo e(route('show.operasional')); ?>/' + year;

      } else {

        window.location = '<?php echo e(route('show.operasional')); ?>/' + year + '/' + month;

      }

    });

  });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('intern.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>