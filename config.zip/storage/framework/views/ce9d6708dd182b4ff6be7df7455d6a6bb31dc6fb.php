<?php $__env->startSection('title', 'E-IKM | Grafik'); ?>

<?php $__env->startSection('barside.title', 'IKM Sumbawa'); ?>

<?php $__env->startSection('content'); ?>

<style type="text/css">
	#total_responden, #nilai_ikm, #layanan_kh, #layanan_kt{
		width: 100%;
		min-height: 310px
	}
</style>
<div class="col-md-12 col-sm-12 col-xs-12">
	<div class="page-title">
	  <div class="title_left">
	    <h3>Statistik & Grafik <?php echo e($ikm_ket->keterangan); ?></h3>
	    <h5>
	    	Periode Survey : 
	    	<?php echo e(date('d-M-Y', strtotime($ikm_ket->start_date))); ?> 
	    	s/d 
	    	<?php echo e(date('d-M-Y', strtotime($ikm_ket->end_date))); ?>

	    </h5>
	  </div>
	</div>
</div>

<div class="clearfix"></div>

<div class="col-md-12">
	<div class="row" style="margin-bottom: 1%">
		<div class="col-sm-4 col-sm-12 col-xs-12">
			<div class="row">
				<label for="select_ikm">Pilih IKM</label>
				<select name="select_ikm" id="select_ikm" class="form-control">
					<option disabled selected>-- Pilih Periode IKM --</option>
					<?php $__currentLoopData = $ikm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($i->id); ?>"><?php echo e($i->keterangan); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
			</div>
		 </div>
	</div>
	<div class="row">
		<div class="col-md-3 col-sm-12 col-xs-12">
			<div class="x_panel">
			  <div class="x_content">
			  	<div class="row">
			  		<div class="col-md-12 text-center" id="nilai_ikm">
						<h2></h2>
						<div class="card card-default">
						  <div class="card-body" style="margin: 70px 0">
						  	<h1 style="font-size: 50pt"></h1>
						  	<i class="fa fa-check-circle" style="font-size: 30pt"></i>
						  </div>
						</div>
					</div>
			  	</div>
			  </div>
			</div>
		</div>

		<div class="col-md-3 col-sm-12 col-xs-12">
			<div class="x_panel">
			  <div class="x_content">
			  	<div class="row">
			  		<div class="col-md-12 text-center" id="total_responden">
						<h2></h2>
						  <div class="card-body" style="margin: 70px 0">
						  	<h1 style="font-size: 50pt"></h1>
						  	<i class="fa fa-line-chart" style="font-size: 30pt"></i>
						  </div>
					</div>
			  	</div>
			  </div>
			</div>
		</div>

		<div class="col-md-3 col-sm-12 col-xs-12">
			<div class="x_panel">
			  <div class="x_content">
			  	<div class="row">
			  		<div class="col-md-12 text-center" id="layanan_kh">
						<h2></h2>
						  <div class="card-body" style="margin: 70px 0">
						  	<h1 style="font-size: 50pt"></h1>
						  	<i class="fa fa-paw" style="font-size: 30pt"></i>
						  </div>
					</div>
			  	</div>
			  </div>
			</div>
		</div>

		<div class="col-md-3 col-sm-12 col-xs-12">
			<div class="x_panel">
			  <div class="x_content">
			  	<div class="row">
			  		<div class="col-md-12 text-center" id="layanan_kt">
						<h2></h2>
						  <div class="card-body" style="margin: 70px 0">
						  	<h1 style="font-size: 50pt"></h1>
						  	<i class="fa fa-leaf" style="font-size: 30pt"></i>
						  </div>
					</div>
			  	</div>
			  </div>
			</div>
		</div>
	</div>
</div>

<?php echo $__env->make('intern.ikm.grafik.chart', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('intern.ikm.grafik.script', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('intern.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>