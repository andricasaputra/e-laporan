<?php $__env->startSection('content'); ?>
<div class="container" style="margin-top: 4%">

  <?php echo $__env->make('inc.message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <h2>Upload Domestik Masuk Karantina Tumbuhan</h2>

  <div class="col-md-12">
    <div class="row">
      <form action="<?php echo e(route('kt.download.proses.domas')); ?>" method="post" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <div class="form-group">
              <input type="file" name="impor">
          </div>
          <input type="submit" name="import" class="btn btn-success" value="Upload">
      </form>
    </div>
  </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>