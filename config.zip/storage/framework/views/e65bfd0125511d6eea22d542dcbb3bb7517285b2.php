<?php $__env->startSection('content'); ?>
<main class="content-wrapper">
    <section class="purchase__card_section custom_section">
        <?php if(Session::has('success')): ?>
                 <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
            <?php endif; ?>

            <form method="POST" action="<?php echo e(route('register')); ?>">
                <?php echo csrf_field(); ?>

                <div class="form-group row">
                    <label for="wilker" class="col-md-4 col-form-label text-md-right">Wilker</label>

                    <div class="col-md-6"> 
                        <?php if(count($wilker) > 0): ?>

                            <select class="form-control<?php echo e($errors->has('wilker') ? ' is-invalid' : ''); ?>" name="wilker" required>
                                <?php $__currentLoopData = $wilker; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <option value="<?php echo e($w->id); ?>"><?php echo e($w->nama_wilker); ?></option>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                        <?php endif; ?>

                        <?php if($errors->has('wilker')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('wilker')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group row">
                    <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nama')); ?></label>

                    <div class="col-md-6">
                        <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name')); ?>" required autofocus>

                        <?php if($errors->has('name')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('name')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group row">
                    <label for="bagian" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Bagian')); ?></label>

                    <div class="col-md-6">
                        <select class="form-control<?php echo e($errors->has('bagian') ? ' is-invalid' : ''); ?>" name="bagian">
                            <option value="kh">Karantina Hewan</option>
                            <option value="kt">Karantina Tumbuhan</option>
                            <option value="fu">Fungsional Umum</option>
                            <option value="-"></option>
                        </select>

                        <?php if($errors->has('bagian')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('bagian')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group row">
                    <label for="role" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Role')); ?></label>

                    <div class="col-md-6">
                        <select class="form-control<?php echo e($errors->has('role') ? ' is-invalid' : ''); ?>" name="role">
                            <option value="2">User</option>
                            <option value="1">Admin</option>
                        </select>

                        <?php if($errors->has('role')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('role')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group row">
                    <label for="username" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Username')); ?></label>

                    <div class="col-md-6">
                        <input id="username" type="username" class="form-control<?php echo e($errors->has('username') ? ' is-invalid' : ''); ?>" name="username" value="<?php echo e(old('username')); ?>" required>

                        <?php if($errors->has('username')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('username')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

            
                <div class="form-group row">
                    <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Password')); ?></label>

                    <div class="col-md-6">
                        <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>

                        <?php if($errors->has('password')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('password')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group row">
                    <label for="password-confirm" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Confirm Password')); ?></label>

                    <div class="col-md-6">
                        <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                    </div>
                </div>

                <div class="form-group row mb-0">
                    <div class="col-md-6 offset-md-4">
                        <button type="submit" class="btn btn-primary">
                            <?php echo e(__('Register')); ?>

                        </button>
                    </div>
                </div>
            </form>
    </section>

</main>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>