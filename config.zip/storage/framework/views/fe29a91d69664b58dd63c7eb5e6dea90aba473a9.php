<?php $__env->startSection('barside'); ?>

  <?php echo $__env->make('intern.inc.barside_manajemen', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<main class="content-wrapper">
  <div class="container-fluid">
   <div class="row">
      <div class="col-md-10 offset-md-1 card">
          <div class="card-header">
            Edit Users
          </div>
          <div class="card-body">

            <?php echo $__env->make('intern.inc.message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <form method="POST" action="<?php echo e(route('users.update', $user->id)); ?>">

                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
            
                <div class="form-group row">
                    <label for="wilker" class="col-md-4 col-form-label text-md-right">Wilker</label>

                    <div class="col-md-6"> 

                        <select class="form-control<?php echo e($errors->has('wilker') ? ' is-invalid' : ''); ?>" name="wilker" required>
                                <option value="<?php echo e($wilker_user->id); ?>"><?php echo e($wilker_user->nama_wilker); ?></option>
                                <?php if(count($wilkers) > 0): ?>

                                    <?php $__currentLoopData = $wilkers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <option value="<?php echo e($wil->id); ?>"><?php echo e($wil->nama_wilker); ?></option>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <?php endif; ?>
                        </select>

                        <?php if($errors->has('wilker')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('wilker')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group row">
                    <label for="nama" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nama')); ?></label>

                    <div class="col-md-6">
                        <input id="nama" type="text" class="form-control<?php echo e($errors->has('nama') ? ' is-invalid' : ''); ?>" name="nama" value="<?php echo e($user->pegawai->nama); ?>" required>

                        <?php if($errors->has('nama')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('nama')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group row">
                    <label for="nip" class="col-md-4 col-form-label text-md-right"><?php echo e(__('NIP')); ?></label>

                    <div class="col-md-6">
                        <input id="nip" type="text" class="form-control<?php echo e($errors->has('nip') ? ' is-invalid' : ''); ?>" name="nip" value="<?php echo e($user->pegawai->nip); ?>">

                        <?php if($errors->has('nip')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('nip')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group row">
                    <label for="pangkat" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Pangkat')); ?></label>

                    <div class="col-md-6">
                        <?php if(count($golongan) > 0): ?>

                            <select class="form-control<?php echo e($errors->has('wilker') ? ' is-invalid' : ''); ?>" name="golongan" >
                                <?php if($golongan_user !== NULL): ?>
                                    <option value="<?php echo e($golongan_user->id); ?>"><?php echo e($golongan_user->golongan); ?></option>
                                <?php else: ?>
                                    <option value="" disabled selected>-- Pilih Pangkat/Golongan --</option>
                                <?php endif; ?>
                                
                                <?php $__currentLoopData = $golongan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <option value="<?php echo e($g->id); ?>"><?php echo e($g->pangkat); ?> - <?php echo e($g->golongan); ?></option>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <option value=""></option>
                            </select>

                        <?php endif; ?>

                        <?php if($errors->has('pangkat')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('pangkat')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group row">
                    <label for="jabatan" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Jabatan')); ?></label>

                    <div class="col-md-6">
                        <?php if(count($jabatan) > 0): ?>

                            <select class="form-control<?php echo e($errors->has('wilker') ? ' is-invalid' : ''); ?>" name="jabatan" >
                                <?php if($jabatan_user !== NULL): ?>
                                    <option value="<?php echo e($jabatan_user->id); ?>"><?php echo e($jabatan_user->jabatan); ?></option>
                                <?php else: ?>
                                    <option value="" disabled selected>-- Pilih Jabatan --</option>
                                <?php endif; ?>
                                
                                <?php $__currentLoopData = $jabatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <option value="<?php echo e($j->id); ?>"><?php echo e($j->jabatan); ?></option>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <option value=""></option>
                            </select>

                        <?php endif; ?>

                        <?php if($errors->has('jabatan')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('jabatan')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group row">
                    <label for="jenis_karantina" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Jenis Karantina')); ?></label>

                    <div class="col-md-6">
                        <select class="form-control<?php echo e($errors->has('jenis_karantina') ? ' is-invalid' : ''); ?>" name="jenis_karantina">
                            <option value="<?php echo e($user->pegawai->jenis_karantina); ?>"> <?php echo e($user->pegawai->jenis_karantina); ?> </option>
                            <option value="kh">Karantina Hewan</option>
                            <option value="kt">Karantina Tumbuhan</option>
                            <option value="fu">Fungsional Umum</option>
                            <option value="-"></option>
                        </select>

                        <?php if($errors->has('jenis_karantina')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('jenis_karantina')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group row">
                    <label for="role" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Role')); ?></label>

                    <div class="col-md-6">
                        
                        <?php if(count($roles) > 0): ?>

                            <?php $__currentLoopData = $user->role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <div class="form-check form-check-inline">
                                  <label><input type="checkbox" name="role[]" value="<?php echo e($user_role->id); ?>" checked><?php echo e($user_role->name); ?></label>
                                </div>
 
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php $__currentLoopData = $roles->filter(function ($item) use ($user_role) {

                                       return $item->id !== $user_role->id && $item->name !== $user_role->name;

                                    }); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <div class="form-check form-check-inline">
                                  <label><input type="checkbox" name="role[]" value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></label>
                                </div>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?php endif; ?>
                        
                        <?php if($errors->has('role')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('role')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>

                </div>

                <div class="form-group row">
                    <label for="username" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Username')); ?></label>

                    <div class="col-md-6">
                        <input id="username" type="username" class="form-control<?php echo e($errors->has('username') ? ' is-invalid' : ''); ?>" name="username" value="<?php echo e($user->username); ?>" required>

                        <?php if($errors->has('username')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('username')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

            
                <div class="form-group row">
                    <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Password Baru')); ?></label>

                    <div class="col-md-6">
                        <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>

                        <?php if($errors->has('password')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('password')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group row">
                    <label for="password-confirm" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Confirm Password')); ?></label>

                    <div class="col-md-6">
                        <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                    </div>
                </div>

                <div class="form-group row mb-0">
                    <div class="col-md-6 offset-md-4">
                        <button type="submit" class="btn btn-primary">
                            <?php echo e(__('Edit')); ?>

                        </button>
                    </div>
                </div>
            </form>
          </div>
      </div>
    </div>
  </div>
</main>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('intern.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>