<?php

namespace App\Contracts;

interface ModelOperasionalInterface
{
	public function getBulanAttribute($value);
}