<?php

namespace App\Contracts;

interface NotificationsEventInterface
{

}