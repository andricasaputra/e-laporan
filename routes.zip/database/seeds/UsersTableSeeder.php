<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('users')->insert([

            [
                'pegawai_id' => 1,
                'username' => 'superadmin',
                'password' => bcrypt('superadmin123')
            ],
            [
                'pegawai_id' => 2,
                'username' => 'admin',
                'password' => bcrypt('admin123')
            ],
            
        ]);
    }
}
