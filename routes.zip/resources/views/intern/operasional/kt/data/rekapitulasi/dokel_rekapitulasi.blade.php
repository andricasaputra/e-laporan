<div class="row">
    <div class="col-sm-12">
      <div class="card">
        <div class="card-body">
          <h4 class="card-title">Rekapitulasi Komoditi Domestik Keluar</h4>
          <table class="table table-bordered" id="DokelKt" style="width: 100%">
            <thead>
              <tr>
                <th>Komoditi</th>
                <th>Jumlah/ Volume</th>
                <th>Satuan</th>
                <th>Frekuensi</th>
                <th>Total PNBP</th>
                <th>Detail</th>
              </tr>
            </thead>
            <tbody></tbody>
          </table>
        </div>
      </div>
    </div>
</div>

