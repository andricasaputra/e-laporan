<?php $__env->startSection('content'); ?>

<style type="text/css">
  .card_body_welcome{
    color: #fff
  }

  .btn{
    border-radius: 30px !important;
    outline: none;
  }

  .btn-default{
    background-color: #3E50B4;
    color: #fff;
    outline: none;
  }

  .btn-default:hover {
    background-color: #2e3b85;
    color: #fff;
    outline: none;
  }

  .card{
    margin-bottom: 0.5%;
  }

  .card, .card-body{
    font-size: 11pt;
    outline: none;
  }

  a.notification-message{
    color: #000
  }

  .card-body:hover a.notification-message{
    text-decoration: none;
    color: #7460EE
  }

  .readed{
    background-color: #d7e2f4;
  }

  .readed a:hover{
    color: #000;
  }

  .delete-notification a{
    color: #000
  }

  .delete-notification a:hover{
    text-decoration: underline;
    color: #7460EE
  }

  ul.pagination{
    text-align: center;
    font-family: 'Open Sans', sans-serif;
    font-weight: 600;
  }

  ul.pagination li.disabled span.page-link{
      border-radius: 12px
  }

  ul.pagination a, li.disabled span.page-link,
  ul.pagination li.active span.page-link
  {
      margin: 0 5px; /* 0 is for top and bottom. Feel free to change it */
  }

  ul.pagination li.page-item a.page-link {
      color: black;
      transition: background-color .3s;
      border-radius: 12px
  }

  ul.pagination li.active span.page-link {
      background: #7460EE !important;
      color: white;
      border :none;
      border-radius: 12px
  }

  @media  only screen and (max-width: 700px){
    .card{
      display: block;
      text-align: center;
    }
    
    i.fa{
        margin-top: 0;
        margin-bottom: 10px;
    }

    .pull-right {
        float: none;
        margin-top: 10px
    }
  }
</style>


<div class="col-sm-12">
  <div class="card">
    <div class="card-body">
      <strong><i class="fa fa-bell fa-fw"></i> Semua Pemberitahuan</strong>
    </div>
  </div>
</div>

<?php echo $__env->make('intern.inc.message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="col-sm-12 mb-4">

  <?php if(count($notifications) > 0): ?>

    <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>            
      <div class="card mt-4">
        <div class="card-body <?php echo e($notification->read_at === null ? 'readed' : ''); ?>">
          <div class="row">
            <div class="col-sm-9">
               <a class="notification-message" href="<?php echo e($notification->data['link']); ?>"><?php echo e($notification->data['message']); ?></a>
            </div>
            <div class="col-sm-3">
              <div class="pull-right">
                <i class="fa fa-bolt" aria-hidden="true"></i> <?php echo e($notification->data['type']); ?> |
                <i class="fa fa-clock-o" aria-hidden="true"></i> <?php echo e(\Carbon\Carbon::createFromTimeStamp(strtotime($notification->created_at))->diffForHumans()); ?>

              </div>
            </div>
          </div>
        </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

    <div class="row mb-3 mt-2 pull-right">
      <div class="col-md-12 delete-notification">
          <i class="fa fa-check"></i> <a href="<?php echo e(route('mark.all.as.read')); ?>" onclick="event.preventDefault();document.getElementById('mark-as-read-all-notification').submit()">Tandai Semua Sudah Dibaca</a> &nbsp;&nbsp;
          <form id="mark-as-read-all-notification" action="<?php echo e(route('mark.all.as.read')); ?>" method="POST" style="display: none;">
            <?php echo csrf_field(); ?>
          </form>
          <i class="fa fa-trash"></i> <a href="<?php echo e(route('delete.all.notifications')); ?>" onclick="event.preventDefault();document.getElementById('delete-notification').submit()">Hapus Semua Notifikasi</a>
          <form id="delete-notification" action="<?php echo e(route('delete.all.notifications')); ?>" method="POST" style="display: none;">
            <?php echo csrf_field(); ?>
          </form>

      </div>
    </div>

  <?php else: ?>

    <div class="card">
        <div class="card-body">
          <div class="row text-center">
            <div class="col-sm-12">
               <a href="#">Tidak Ada Pemberitahuan Terbaru</a>
            </div>
          </div>
        </div>
    </div>

  <?php endif; ?>
       
</div>


<div class="mb-3 mt-2">
  <div class="col-md-12 align-items-center d-flex justify-content-center">
       <?php echo e($notifications->links()); ?>

  </div>
</div>

<div class="row">
  <div class="col-sm-12 text-center">
    <a href="<?php echo e(route('welcome')); ?>" class="btn btn-primary">kembali ke halaman utama</a>
  </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('intern.layouts.welcome_app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>