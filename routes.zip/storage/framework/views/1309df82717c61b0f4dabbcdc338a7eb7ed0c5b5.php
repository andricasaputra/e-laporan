<aside class="mdc-persistent-drawer mdc-persistent-drawer--open" style="height: 100%">
  <?php if(auth()->guard()->check()): ?>
  <nav class="mdc-persistent-drawer__drawer" >
    <div class="mdc-persistent-drawer__toolbar-spacer">
      <a href="<?php echo e(route('home')); ?>" class="brand-logo"><!--<img src="../../images/logo.svg" alt="logo">--></a>
    </div>
    <div class="mdc-list-group"> 
      <nav class="mdc-list mdc-drawer-menu">

        <div class="mdc-list-item mdc-drawer-item">
          <a class="mdc-drawer-link" href="<?php echo e(route('home')); ?>">
            <i class="fa fa-home fa-custom"></i>
            Home
          </a>
        </div>

        <?php if(Auth::user()->role_id == 1 && Auth::user()->bagian == '-'): ?>

          <?php echo $__env->make('inc.barside_kt', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <?php echo $__env->make('inc.barside_kh', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php elseif(Auth::user()->role_id != 1 && Auth::user()->bagian == 'kt'): ?>

          <?php echo $__env->make('inc.barside_kt', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php else: ?>

          <?php echo $__env->make('inc.barside_kh', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          
        <?php endif; ?>

         <?php if( Auth::user()->role_id == 1 ): ?>
            <?php if(Route::has('register')): ?>

                <div class="mdc-list-item mdc-drawer-item"  data-toggle="expansionPanel" target-panel="user-management">
                <a class="mdc-drawer-link" href="#">
                   <i class="fa fa-gear fa-custom" aria-hidden="true"></i>
                  User Management
                  <i class="mdc-drawer-arrow material-icons">arrow_drop_down</i>
                </a>
                <div class="mdc-expansion-panel" id="user-management">
                  <nav class="mdc-list mdc-drawer-submenu">
                    <div class="mdc-list-item mdc-drawer-item">
                      <a class="mdc-drawer-link" href="<?php echo e(route('users.show')); ?>">
                        Lihat Data
                      </a>
                    </div>
                    <div class="mdc-list-item mdc-drawer-item">
                      <a class="mdc-drawer-link" href="<?php echo e(route('register')); ?>">
                        Register New User
                      </a>
                    </div>
                  </nav>
                </div>
              </div>
              
            <?php endif; ?>
        <?php endif; ?>

      </nav>
    </div>
  </nav>
  <?php endif; ?>
</aside>