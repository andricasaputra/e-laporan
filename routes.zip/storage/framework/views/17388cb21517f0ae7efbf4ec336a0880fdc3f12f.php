<?php $__env->startSection('content'); ?>

<main class="content-wrapper">
  <div class="mdc-layout-grid">
    <div class="mdc-layout-grid__inner">
      <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-12">
          <div class="mdc-card">
            <div class="mdc-layout-grid__inner">
              <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-7">
                <section class="purchase__card_section">

                    <?php echo $__env->make('inc.message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <h4>Upload Domestik Keluar Karantina Hewan</h4>
                    <div class="col-md-12">
                      <div class="row">
                        <form action="<?php echo e(route('kh.upload.proses.dokel')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">

                            <div class="form-group">
                              <label for="wilker_id">Nama Wilker</label>
                              <select name="wilker_id" class="form-control">
                               
                                <?php if(count($wilker) == 8): ?>

                                    <option disabled selected>Pilih Wilker</option>

                                  <?php $__currentLoopData = $wilker; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <option value="<?php echo e($w->id); ?>"><?php echo e($w->nama_wilker); ?></option>

                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <?php else: ?> 

                                    <option value="<?php echo e($wilker['id']); ?>"><?php echo e($wilker['nama_wilker']); ?></option>

                                <?php endif; ?>
                                
                              </select>
                            </div>

                            <div class="form-group">
                              <label for="filenya">Pilih File Laporan</label>
                              <input type="file" name="filenya" class="form-control">
                            </div>
                            <input type="submit" name="Import" class="btn btn-success" value="Upload">
                        </form>
                      </div>
                    </div>
                </section>
              </div>
            </div>
          </div>
        </div>
    </div>
  </div>
</main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>