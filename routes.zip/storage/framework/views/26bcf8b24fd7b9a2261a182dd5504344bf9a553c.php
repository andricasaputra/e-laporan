<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <!-- CSRF Token -->
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <meta content="e-Office-sumbawa" name="keywords">
  <meta content="e-Office-sumbawa" name="description">
  <meta name="mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="application-name" content="e-Office">
  <meta name="apple-mobile-web-app-title" content="e-Office">
  <meta name="theme-color" content="#00A9F4">
  <meta name="msapplication-navbutton-color" content="#00A9F4">
  <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
  <meta name="msapplication-starturl" content="/login">
  
  <title><?php echo $__env->yieldContent('title', 'E-Office Karantina Sumbawa'); ?></title>
  
  <link rel="manifest" href="<?php echo e(asset('manifest.json')); ?>">
  <link rel="icon" type="image/png" href="<?php echo e(asset('images/favicon-32x32.png')); ?>" sizes="32x32">
  <link rel="icon" type="image/png" sizes="48x48" href="<?php echo e(asset('images/web-sumbawa1x.png')); ?>">
  <link rel="apple-touch-icon" type="image/png" sizes="48x48" href="<?php echo e(asset('images/web-sumbawa1x.png')); ?>">
  <link rel="icon" type="image/png" sizes="96x96" href="<?php echo e(asset('images/web-sumbawa2x.png')); ?>">
  <link rel="apple-touch-icon" type="image/png" sizes="96x96" href="<?php echo e(asset('images/web-sumbawa2x.png')); ?>">
  <link rel="icon" type="image/png" sizes="192x192" href="<?php echo e(asset('images/web-sumbawa3x.png')); ?>">
  <link rel="apple-touch-icon" type="image/png" sizes="192x192" href="<?php echo e(asset('images/web-sumbawa3x.png')); ?>">
  <link rel="icon" type="image/png" sizes="512x512" href="<?php echo e(asset('images/web-sumbawa4x.png')); ?>">
  <link rel="apple-touch-icon" type="image/png" sizes="512x512" href="<?php echo e(asset('images/web-sumbawa4x.png')); ?>">
  
  <link rel="icon" href="<?php echo e(asset('images/favicon-32x32.png')); ?>" type="image/png" sizes="32x32">
  <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/util.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
  <style>
    @media  only screen and (max-width: 700px){
        .limiter .container-login100{
            margin-top: -20%;
        }
        
        img{
            margin-top: -5%;
        }
        
        .wrap-input100:first-of-type{
            margin-top: 5%;
        }
    }
  </style>
</head>

<body>

    <div class="limiter">
        <div class="container-login100">
            <div class="wrap-login100 p-t-85 p-b-20">

                <?php if(Session::has('success')): ?>
                   <div class="alert alert-success text-center"><?php echo e(Session::get('success')); ?></div>
                <?php elseif(Session::has('warning')): ?>
                    <div class="alert alert-danger text-center"><?php echo e(Session::get('warning')); ?></div>
                <?php endif; ?>

                <?php if($errors->any()): ?>
                  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="alert alert-danger text-center"><?php echo e($error); ?></div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                
                <form class="login100-form validate-form" method="POST" action="<?php echo e(route('login')); ?>">

                    <?php echo csrf_field(); ?>

                    <span class="login100-form-title p-b-70">
                        Login To E-office
                    </span>

                    <span class="login100-form-avatar">
                        <img src="<?php echo e(asset('images/web-sumbawa4x.png')); ?>" alt="logo">
                    </span>

                    <div class="wrap-input100 validate-input m-t-85 m-b-35" data-validate = "Enter username">
                        <label for="username"></label>
                        <input type="text" class="input100<?php echo e($errors->has('username') ? ' is-invalid' : ''); ?>" name="username" value="<?php echo e(old('username')); ?>" required autofocus placeholder="Username">
                        <?php if($errors->has('username')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('username')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>

                    <div class="wrap-input100 validate-input m-b-50" data-validate="Enter password">
                        <label for="pass"></label>
                        <input type="password" name="password" class="input100<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" placeholder="Password" required>
                        <?php if($errors->has('password')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('password')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>

                    <div class="container-login100-form-btn">
                        <button class="login100-form-btn">
                            Login
                        </button>
                    </div>

                    <ul class="login-more p-t-190">
                        <li class="m-b-8">
                            <input class="txt1 form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>

                            <label class="txt2 form-check-label" for="remember">
                                <?php echo e(__('Remember Me')); ?>

                            </label>
                        </li>
                    </ul>
                </form>
            </div>
        </div>
    </div>
    

</body>

</html>
