<?php $__env->startSection('content'); ?>
<div class="container" style="margin-top: 4%">

  <?php if(Session::has('success')): ?>
     <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
  <?php elseif(Session::has('warning')): ?>
      <div class="alert alert-danger"><?php echo e(Session::get('warning')); ?></div>
  <?php endif; ?>

  <h2>Import Domestik Keluar Karantina Tumbuhan</h2>

  <div class="col-md-12">
    <div class="row">
      <form action="<?php echo e(route('dokelkt.import')); ?>" method="post" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <div class="form-group">
              <input type="file" name="impor">
          </div>
          <input type="submit" name="Import" class="btn btn-success">
      </form>
    </div>
  </div>

  <div class="col-md-12" style="margin-top: 4%">
    <div class="row">
      <a href="<?php echo e(route('page.domas')); ?>" class="btn btn-primary">Import Domestik Masuk</a>
    </div>    
  </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>