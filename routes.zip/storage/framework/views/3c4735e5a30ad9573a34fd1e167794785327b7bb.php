<?php $__env->startSection('title', 'Home Operasional - Halaman Utama'); ?>

<?php $__env->startSection('barside'); ?>

  <?php echo $__env->make('intern.inc.barside_operasional', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-breadcrumb'); ?>

<h4 class="page-title">Rekapitulasi Data Operasional Karantina Tumbuhan</h4>
<div class="d-flex align-items-center">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('show.operasional')); ?>">Home</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('showmenu.operasional.kt')); ?>">Menu Utama</a></li>
            <li class="breadcrumb-item" aria-current="page"><a href="<?php echo e(route('showmenu.data.operasional.kt')); ?>">Menu Data Operasional Karantina Tumbuhan</a></li>
            <li class="breadcrumb-item" aria-current="page">Rekapitulasi Komoditi</li>
        </ol>
    </nav>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?> 

<style>
   table tr th, table tr td:not(:nth-of-type(1)){
    text-align: center;
  }

  table tr td{
    font-size: 11pt;
    font-weight: bold;
  }

  table tr.active{
    background-color:#eee;
  }
</style>

<?php use App\Http\Controllers\TanggalController as Tanggal; ?>

<div class="container-fluid">

  <div class="col">

      <?php if($datas['bulan'] !== null): ?>
      <h3>
          Rekapitulasi Data Operasional Karantina Tumbuhan Bulan 
          <?php echo e(Tanggal::bulan($datas['bulan'])); ?> Tahun <?php echo e($datas['tahun']); ?>

          <?php echo e($datas['wilker']); ?>

        </h3>
      <?php else: ?>
        <h3>Rekapitulasi Data Operasional Karantina Tumbuhan Tahun <?php echo e($datas['tahun']); ?></h3>
      <?php endif; ?>

      <form id="change_data_rekapitulasi_kt">
        <div class="row mb-3">
          <div class="col-md-4 col-sm-12">
            <label for="year">Pilih Tahun</label>
            <select class="form-control" name="year" id="year">
              <?php for($i = date('Y') - 3; $i < date('Y') + 2 ; $i++): ?>
          
                <?php if($i == $datas['tahun']): ?>

                  <option value="<?php echo e($i); ?>" selected><?php echo e($i); ?></option>

                <?php else: ?>

                  <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>

                <?php endif; ?>

              <?php endfor; ?>
            </select>
          </div>

          <div class="col-md-4 col-sm-12">
            <label for="month">Pilih Bulan</label>
            <select class="form-control" name="month" id="month">
              <option value="all">Semua</option>
              <?php for($i = 1; $i < 13 ; $i++): ?>
          
                <?php if($i == $datas['bulan']): ?>

                  <option value="<?php echo e($i); ?>" selected><?php echo e(Tanggal::bulan($i)); ?></option>

                <?php else: ?>

                  <option value="<?php echo e($i); ?>"><?php echo e(Tanggal::bulan($i)); ?></option>

                <?php endif; ?>

              <?php endfor; ?>
              
            </select>
          </div>

          <div class="col-md-4 col-sm-12">
            <label for="wilker">Pilih Wilker</label>
            <select class="form-control" name="wilker" id="wilker">

              <option value="">Semua</option>

              <?php $__currentLoopData = $wilkers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wilker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php if(isset($datas['wilker']) && $datas['wilker'] == $wilker->nama_wilker): ?>

                <option value="<?php echo e($wilker->id); ?>" selected><?php echo e($wilker->nama_wilker); ?></option>

                <?php else: ?>

                <option value="<?php echo e($wilker->id); ?>"><?php echo e($wilker->nama_wilker); ?></option>

                <?php endif; ?>
                
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </select>
          </div>

          <div class="col-md-4 col-sm-12 mt-3">
           <button type="submit" class="btn btn-danger">Pilih</button>
          </div>

        </div>
      </form>

      <?php echo $__env->make('intern.operasional.kt.data.rekapitulasi.domas_rekapitulasi', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php echo $__env->make('intern.operasional.kt.data.rekapitulasi.dokel_rekapitulasi', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php echo $__env->make('intern.operasional.kt.data.rekapitulasi.ekspor_rekapitulasi', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php echo $__env->make('intern.operasional.kt.data.rekapitulasi.impor_rekapitulasi', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

      <div class="row">
        <div class="col">
          <div class="text-center">
            <a href="<?php echo e(route('showmenu.data.operasional.kt')); ?>" class="btn btn-default"><i class="fa fa-angle-double-left"></i> Kembali</a>
          </div>
        </div>
      </div>

    
  </div>

</div> 

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

  <?php echo $__env->make('intern.operasional.kt.data.rekapitulasi.script', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('intern.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>