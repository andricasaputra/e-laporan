<?php $__env->startSection('title', 'Tambah Layanan IKM'); ?>

<?php $__env->startSection('barside.title', 'IKM Sumbawa'); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-12 col-sm-12 col-xs-12">
	<div class="page-title">
	  <div class="title_left">
	    <h3>Tambah Data Layanan IKM</h3>
	  </div>
	</div>
</div>

<div class="clearfix"></div>

<div class="col-md-12 col-sm-12 col-xs-12">
	<div class="x_panel">
	  <div class="x_title">
	    <a href="<?php echo e(route('intern.ikm.layanan.index')); ?>" class="btn btn-primary"><i class="fa fa-arrow-left"></i> Kembali</a>
	    <ul class="nav navbar-right panel_toolbox">
	      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
	      </li>
	    </ul>
	    <div class="clearfix"></div>
	  </div>
	  <div class="x_content">

	  	<form action="<?php echo e(route('intern.ikm.layanan.store')); ?>" method="post" enctype="multipart/form-data">

	  		<?php echo csrf_field(); ?>

	  		<div class="form-group">
	  			<label for="layanan">Layanan</label>
	  			<input type="text" name="layanan" class="form-control" value="<?php echo e(old('layanan')); ?>">
	  		</div>
	  		<div class="pull-right">
	  			<input type="submit" name="submit" value="Simpan" class="btn btn-warning">
	  		</div>

	  	</form>

	  </div>
	</div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('intern.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>