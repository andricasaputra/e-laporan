

<div class="col-md-3 offset-md-1 col-sm-12">
    <div class="card">
      <div class="card-body">
        <ul class="list-group">
          <li class="list-group-item active">Keterangan : </li>
        </ul>
        <div class="list-group">
          <a href="#" class="list-group-item list-group-item-action flex-column align-items-start">
            <p class="mb-1"><b>Tipe Dokumen Harus Berupa Excel!</b></p>
          </a>
          <a href="#" class="list-group-item list-group-item-action flex-column align-items-start">
            <p class="mb-1"><b> File Laporan Harus asli dari iqfast tanpa perubahan apapun </b> jika file mengalami perubahan atau tidak sesuai maka file akan dianggap <b> bukan hasil export dari iqfast </b></p>
          </a>
          <a href="#" class="list-group-item list-group-item-action flex-column align-items-start">
            <p class="mb-1">File laporan harus dipisahkan <b> per bulan </b> & sesuai jenis permohonan masing -masing <b> (domas, dokel, ekspor, impor) </b> </p>
          </a>
          <a href="#" class="list-group-item list-group-item-action flex-column align-items-start">
            <p class="mb-1"><b>Untuk kegiatan yang nihil, laporan operasional tetap wajib diupload!</b></p>
          </a>
          <a href="#" class="list-group-item list-group-item-action flex-column align-items-start">
            <p class="mb-1">Pastikan <b> Total PNBP tidak 0 </b> untuk dokumen pelepasan yang dikenakan tarif PNBP</p>
          </a>
          <a href="#" class="list-group-item list-group-item-action flex-column align-items-start">
            <p class="mb-1">Periksa kembali file laporan anda sebelum mengupload ke server database!</p>
          </a>
          <a href="#" class="list-group-item list-group-item-action flex-column align-items-start">
            <p class="mb-1"><b>Pilihan wilker telah disesuaikan untuk masing - masing pegawai </b>, <span style="color: red; font-style: italic;"> untuk pegawai yang bertugas di lebih dari satu wilker harap lebih teliti dalam pemilihan wilker, kesalahan pemilihan wilker akan berakibat data operasional menjadi kacau! </span></p>
          </a>
          <a href="#" class="list-group-item list-group-item-action flex-column align-items-start">
            <p class="mb-1">Apabila ada perubahan data pada laporan yang diupload, silahkan unggah kembali laporan terbaru anda. Sistim akan secara otomatis mengupdate data menjadi yang terbaru</p>
          </a>
          <a href="#" class="list-group-item list-group-item-action flex-column align-items-start">
            <p class="mb-1">Data operasional yang telah diupload <b> dapat ditarik kembali dalam kurun waktu satu minggu </b>setelah data berhasil diupload, <b> selebihnya data akan terkunci dan dianggap valid! </b></p>
          </a>
        </div>
      </div>
    </div>
 </div>