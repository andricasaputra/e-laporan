<?php $__env->startSection('title', 'E-IKM | Show'); ?>

<?php $__env->startSection('barside.title', 'IKM Sumbawa'); ?>

<?php $__env->startSection('content'); ?>

<style type="text/css">
	table td:not(:first-of-type){
		text-align: left;
	}
</style>

<div class="col-md-12 col-sm-12 col-xs-12">
	<div class="page-title">
	  <div class="title_left">
	    <h3>Hasil Survey IKM</h3>
	  </div>
	</div>
</div>
<div class="clearfix"></div>

<div class="col-md-12 col-sm-12 col-xs-12">
	<div class="x_panel">
	  <div class="x_title">
		<a href="<?php echo e(route('intern.ikm.home.index')); ?>" class="btn btn-primary"><i class="fa fa-arrow-left"></i> Kembali</a>
		<ul class="nav navbar-right panel_toolbox">
		  <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
		  </li>
		</ul>
		<div class="clearfix"></div>
	  </div>
	  <div class="x_content">
	  	<div id="info_responden"></div>
	    <table id="adminShowIkm" class="table table-striped text-center" width="100%">
	      <thead>
	        <tr>
	          <th>No</th>
	          <th>Pertanyaan</th>
	          <th>Jawaban</th>
	          <th>Nilai</th>
	        </tr>
	      </thead>
	    </table>
	  </div>
	</div>
</div>

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

  <script>

    $(document).ready(function() {

    	let url = '<?php echo e(route('api.show', [$responden->id, $year])); ?>';

    	let data = [

	    	{ "data" : "DT_Row_Index", orderable: false, searchable: false},
	        { "data" : "question.question" },
	        { "data" : "answer.answer" },
	        { "data" : "answer.nilai" }

		]

	    $('#adminShowIkm').DataTable({

            "processing": false,
            "serverSide": true,
            "paginate" : false,
	        "lengthChange" : false,
	        "order" : false,
	        "searching": false,
	        "bInfo": false,
            "ajax":{
               "url": url,
               "dataType": "JSON"
            },
            "columns": data,
			"columnDefs": [{
			    "defaultContent": "-",
			    "targets": "_all"
			}]

        });

        $.ajax({

        	url : url

        }).done(function(result){
        	
        	$('#info_responden').html(

        	`<h4>IKM Periode: ${result.data[0].ikm.keterangan}</h4>
        	<h4>ID Responden: ${result.data[0].responden.id}</h4>
        	`

        );
        });

  	});

  </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('intern.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>