<?php $__env->startSection('barside'); ?>

  <?php echo $__env->make('intern.inc.barside_operasional', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-breadcrumb'); ?>

<h4 class="page-title">Upload Data Operasional Domestik Keluar Karantina Hewan</h4>
<div class="d-flex align-items-center">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('show.operasional')); ?>">Home</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('showmenu.operasional.kh')); ?>">Menu</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('kh.homeupload')); ?>">Upload</a></li>
            <li class="breadcrumb-item" aria-current="page">Domestik Keluar</li>
        </ol>
    </nav>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
  <div class="col-md-6 offset-md-2 col-sm-12">

    <?php echo $__env->make('intern.inc.message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="card text-center">
      <div class="card-body">
        <h4>Upload Domestik Keluar Karantina Hewan</h4>
        <form action="<?php echo e(route('kh.upload.proses.dokel')); ?>" method="post" enctype="multipart/form-data" class="form-loader">
            <?php echo csrf_field(); ?>

            <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">

            <input type="hidden" name="jenis_permohonan" value="Domestik Keluar">

            <div class="form-group">
              <label for="wilker_id">Nama Wilker</label>
              <select name="wilker_id" class="form-control">
               
                <?php if(count($wilker) > 0): ?>

                    <option disabled selected>Pilih Wilker</option>

                    <?php $__currentLoopData = $wilker; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                      <option value="<?php echo e($w->id); ?>"><?php echo e($w->nama_wilker); ?></option>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
                <?php endif; ?>
                
              </select>
            </div>

            <div class="form-group">
              <label for="filenya">Pilih File Laporan</label>
              <input type="file" name="filenya" class="form-control">
            </div>
            <input type="submit" name="Import" class="btn btn-success" value="Upload">
        </form>
      </div>
    </div>
    <div class="col">
      <div class="text-center">
        <a href="<?php echo e(route('kh.homeupload')); ?>" class="btn btn-default"><i class="fa fa-angle-double-left"></i> Kembali</a>
      </div>
    </div>
  </div>  

  <?php echo $__env->make('intern.operasional.rules.rule', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('intern.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>