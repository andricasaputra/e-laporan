<?php $__env->startSection('title', 'Home Operasional - Halaman Utama'); ?>

<?php $__env->startSection('barside'); ?>

  <?php echo $__env->make('intern.inc.barside_operasional', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-breadcrumb'); ?>

<h4 class="page-title">Statistik Data Operasional Karantina Hewan</h4>
<div class="d-flex align-items-center">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('show.operasional')); ?>">Home</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('showmenu.operasional.kh')); ?>">Menu Utama</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('showmenu.data.operasional.kh')); ?>">Menu Data Operasional Karantina Hewan</a></li>
            <li class="breadcrumb-item" aria-current="page">Statistik Data Operasional Karantina Hewan</li>
        </ol>
    </nav>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<style type="text/css">
  .card {
    width: 100%;
    margin-bottom: 5%;
  }

  table tr th, table tr td:not(:nth-child(1)) {
    text-align: center;
  }
</style>

<?php 

use App\Http\Controllers\TanggalController as Tanggal; 
use App\Http\Controllers\RupiahController as Rupiah; 

?>

<div class="container-fluid">

  <div class="col">
    
    <?php if($datas['bulan'] !== null): ?>
      <h3>
        Statistik Data Operasional Karantina Hewan Bulan 
        <?php echo e(Tanggal::bulan($datas['bulan'])); ?> Tahun <?php echo e($datas['tahun']); ?>

        <?php echo e($datas['wilker']); ?>

      </h3>
    <?php else: ?>
      <h3>Statistik Data Operasional Karantina Hewan Tahun <?php echo e($datas['tahun']); ?></h3>
    <?php endif; ?>

    <form id="change_data">
      <div class="row mb-3">
        <div class="col-md-4 col-sm-12">
          <label for="year">Pilih Tahun</label>
          <select class="form-control" name="year" id="year">
            <?php for($i = date('Y') - 3; $i < date('Y') + 2 ; $i++): ?>
        
              <?php if($i == $datas['tahun']): ?>

                <option value="<?php echo e($i); ?>" selected><?php echo e($i); ?></option>

              <?php else: ?>

                <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>

              <?php endif; ?>

            <?php endfor; ?>
          </select>
        </div>

        <div class="col-md-4 col-sm-12">
          <label for="month">Pilih Bulan</label>
          <select class="form-control" name="month" id="month">
            <option value="all">Semua</option>
            <?php for($i = 1; $i < 13 ; $i++): ?>
        
              <?php if($i == $datas['bulan']): ?>

                <option value="<?php echo e($i); ?>" selected><?php echo e(Tanggal::bulan($i)); ?></option>

              <?php else: ?>

                <option value="<?php echo e($i); ?>"><?php echo e(Tanggal::bulan($i)); ?></option>

              <?php endif; ?>

            <?php endfor; ?>
            
          </select>
        </div>

        <div class="col-md-4 col-sm-12">
          <label for="wilker">Pilih Wilker</label>
          <select class="form-control" name="wilker" id="wilker">

            <option value="">Semua</option>

            <?php $__currentLoopData = $wilkers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wilker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <?php if(isset($datas['wilker']) && $datas['wilker'] == $wilker->nama_wilker): ?>

              <option value="<?php echo e($wilker->id); ?>" selected><?php echo e($wilker->nama_wilker); ?></option>

              <?php else: ?>

              <option value="<?php echo e($wilker->id); ?>"><?php echo e($wilker->nama_wilker); ?></option>

              <?php endif; ?>
              
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </select>
        </div>

        <div class="col-md-4 mt-3">
         <button type="submit" class="btn btn-danger">Pilih</button>
        </div>

      </div>
    </form>

    <h3>Frekuensi <i class="fa fa-bar-chart" aria-hidden="true"></i></h3>

    <hr>

    <div class="row">
      <?php $__currentLoopData = $datas['dataKh']['frekuensiPerKegiatan']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-sm-3">
          <div class="card">
            <div class="card-body text-center">
              <div class="row">
                <div class="col-sm-12 card_body_welcome" style="min-height: 150px">
                    <h4 class="card-title"><?php echo e($key); ?></h4>
                    <hr>
                    <small><i>Berdasarkan Sertifikasi</i></small>
                    <h5 class="card-text mt-2"><i>Frekuensi : <?php echo e($data['frekuensi']); ?></i></h5>
                </div>
              </div>
              <a href="<?php echo e($data['link']); ?>" class="btn btn-primary"><i class="fa fa-info-circle" aria-hidden="true"></i>  Detail</a>
            </div>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <h3>Volume <i class="fa fa-area-chart" aria-hidden="true"></i></h3>

    <hr>

    <div class="row">
      <?php $__currentLoopData = $datas['dataKh']['totalVolumeBySatuan']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-sm-3">
          <div class="card">
            <div class="card-body text-center">
              <div class="row">
                <div class="col-sm-12 card_body_welcome" style="min-height: 150px">
                    <h4 class="card-title"><?php echo e($key); ?></h4>
                    <hr>
                    <small><i>Berdasarkan Satuan</i></small>
                    <?php if(count($data['volume']) > 0): ?>
                      <?php $__currentLoopData = $data['volume']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $volume): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <h5 class="card-text mt-2">
                        <i> Volume :  <?php echo e($volume->sum('volume')); ?> <?php echo e(ucfirst($k)); ?></i>
                      </h5>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                      <h5 class="card-text mt-2">
                        <i> Volume :  0</i>
                      </h5>
                    <?php endif; ?>
                </div>
              </div>
              <a href="<?php echo e($data['link']); ?>" class="btn btn-default"><i class="fa fa-info-circle" aria-hidden="true"></i>  Detail</a>
            </div>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <h3>PNBP <i class="fa fa-money" aria-hidden="true"></i></h3>

    <hr>

    <div class="row">
      <?php $__currentLoopData = $datas['dataKh']['totalPNBP']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-sm-3">
          <div class="card">
            <div class="card-body text-center">
              <div class="row">
                <div class="col-sm-12 card_body_welcome" style="min-height: 150px">
                    <h4 class="card-title"><?php echo e($key); ?></h4>
                    <hr>
                    <small><i>Berdasarkan Jenis Permohonan</i></small>
                      <h5 class="card-text mt-2">
                        <i>PNBP :  <?php echo e(Rupiah::rp($data['pnbp'])); ?></i>
                      </h5>
                </div>
              </div>
              <a href="<?php echo e($data['link']); ?>" class="btn btn-warning" style="color: #000"><i class="fa fa-info-circle" aria-hidden="true"></i>  Detail</a>
            </div>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <h3>Pemakaian Dokumen <i class="fa fa-book" aria-hidden="true"></i></h3>

    <hr>

    <div class="row">
      <?php $__currentLoopData = $datas['dataKh']['Dokumen']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-sm-3">
          <div class="card">
            <div class="card-body text-center">
              <div class="row">
                <div class="col-sm-12 card_body_welcome" style="min-height: 150px">
                    <h4 class="card-title"><?php echo e($key); ?></h4>
                    <hr>
                    <small><i>Berdasarkan Frekuensi</i></small>
                    <?php if(count($data['dokumen']) > 0): ?>
                      <?php $__currentLoopData = $data['dokumen']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dokumen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <h5 class="card-text mt-2">
                          <i> <?php echo e($dokumen['dokumen']); ?> :  <?php echo e($dokumen['total']); ?> Dokumen</i>
                        </h5>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                      <h5 class="card-text mt-2">
                        <i>0 Dokumen</i>
                      </h5>
                    <?php endif; ?>
                </div>
              </div>
              <a href="<?php echo e($data['link']); ?>" class="btn btn-success"><i class="fa fa-info-circle" aria-hidden="true"></i>  Detail</a>
            </div>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="row">
      <div class="col">
        <div class="text-center">
          <a href="<?php echo e(route('showmenu.data.operasional.kh')); ?>" class="btn btn-danger"><i class="fa fa-angle-double-left"></i> Kembali</a>
        </div>
      </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script>
  $(document).ready(function(){

    $('#change_data').on('submit', function(e){

      e.preventDefault();

      let year = $('#year').val();

      let month = $('#month').val();

      let wilker = $('#wilker').val();

      if (year != '' && month == '' && wilker == '') {

        window.location = '<?php echo e(route('show.statistik.operasional.kh')); ?>/' + year;

      } else if(year != '' && month != '' && wilker == '') {

        window.location = '<?php echo e(route('show.statistik.operasional.kh')); ?>/' + year + '/' + month;

      } else {

        window.location = '<?php echo e(route('show.statistik.operasional.kh')); ?>/' + year + '/' + month + '/' + wilker;

      }

    });

  });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('intern.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>