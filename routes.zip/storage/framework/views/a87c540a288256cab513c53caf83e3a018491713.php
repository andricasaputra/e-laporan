<div class="mdc-list-item mdc-drawer-item">
  <a class="mdc-drawer-link" href="<?php echo e(route('showmenu.operasional.kt')); ?>">
    <i class="material-icons mdc-list-item__start-detail mdc-drawer-item-icon" aria-hidden="true">desktop_mac</i>
    Data Operasional KT
  </a>
</div>


