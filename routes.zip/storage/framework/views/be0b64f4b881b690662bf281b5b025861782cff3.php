<?php $__env->startSection('title', 'Home Operasional - Halaman Utama'); ?>

<?php $__env->startSection('barside'); ?>

  <?php echo $__env->make('intern.inc.barside_operasional', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-breadcrumb'); ?>

<h4 class="page-title">Data Operasional Karantina Tumbuhan</h4>
<div class="d-flex align-items-center">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('show.operasional')); ?>">Home</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('showmenu.operasional.kt')); ?>">Menu</a></li>
            <li class="breadcrumb-item" aria-current="page">Data Operasional Karantina Tumbuhan</li>
        </ol>
    </nav>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<style type="text/css">
  .card {
    width: 100%;
    margin-bottom: 5%;
  }
</style>

<main class="content-wrapper">
    <div class="mdc-layout-grid">
      <div class="mdc-layout-grid__inner">
        <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-12">
          <div class="mdc-card">
            <div class="mdc-layout-grid__inner">
              <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-7">
                <section class="purchase__card_section">
                    Data Operasional Tahun <?php echo e($datas['tahun']); ?>

                </section>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="container-fluid">

      <div class="col">
        
        <div class="row mb-3 mt-2">
          <div class="col-md-2 col-sm-12">
            <div class="form-group">
              <label>Pilih Tahun</label>
              <select class="form-control" name="year" id="year">
                <?php for($i = date('Y') - 3; $i < date('Y') + 2 ; $i++): ?>
            
                  <?php if($i == $datas['tahun']): ?>

                    <option value="<?php echo e($i); ?>" selected><?php echo e($i); ?></option>

                  <?php else: ?>

                    <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>

                  <?php endif; ?>

                <?php endfor; ?>
              </select>
            </div>
          </div>
        </div>

        <div class="row">
          <?php $__currentLoopData = $datas['kt']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-3">
              <div class="card">
                <div class="card-body">
                  <div class="row">
                    <div class="col-sm-12 card_body_welcome">
                        <h4 class="card-title"><?php echo e($key); ?></h4>
                        <small><i>Berdasarkan Sertifikasi</i></small>
                        <h5 class="card-text"><i>Frekuensi : <?php echo e($data['frekuensi']); ?></i></h5>
                        <a href="<?php echo e($data['link']); ?>" class="btn btn-success btn-xs">Detail</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
      </div>

    </div> 

</main>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script>
  $(document).ready(function(){

    $('#year').on('change', function() {

      let year = $(this).val();

      window.location = '<?php echo e(route('show.operasional.kt')); ?>/' + year;

    });

  });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('intern.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>