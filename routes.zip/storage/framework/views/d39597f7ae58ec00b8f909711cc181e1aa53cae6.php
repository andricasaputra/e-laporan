<?php $__env->startSection('title','Operasional - Data Domestik Keluar'); ?>	

<?php $__env->startSection('barside'); ?>

  <?php echo $__env->make('intern.inc.barside_operasional', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>
		
<?php $__env->startSection('content'); ?>

<style type="text/css">
 table th, table tbody, table td{
    text-align: center !important;
  }
  table td:not(:first-of-type){
	min-width: 150px !important;
  }
</style>

<main class="content-wrapper">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-2 offset-md-1 mb-3">
        <form action="<?php echo e(route('view.select.year')); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <div class="form-group">
            <label>Tahun</label>
            <select class="form-control" name="year">
              <?php for($i = date('Y') - 3; $i < date('Y') + 2 ; $i++): ?>

                <?php if($i == $tahun): ?>

                  <option value="<?php echo e(route('kt.view.page.dokel', $i)); ?>" selected><?php echo e($i); ?></option>

                <?php else: ?>

                  <option value="<?php echo e(route('kt.view.page.dokel', $i)); ?>"><?php echo e($i); ?></option>

                <?php endif; ?>
                
              <?php endfor; ?>
            </select>
          </div>
          <button type="submit" class="btn btn-default">Pilih</button>
        </form>
      </div>
      <div class="col-md-10 offset-md-1 card">
          <?php echo $__env->make('intern.inc.message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <div class="card-header">
            Data Domestik Keluar Karantina Tumbuhan Tahun <?php echo e($tahun); ?>

          </div>
          <div class="card-body">
             <table class="table table-responsive table-bordered w-100 d-block d-md-table" id="dokelkt">
              <thead>
              	<?php $__currentLoopData = $titles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              		<th><?php echo e(ucwords(str_replace('_', ' ', $title))); ?></th>
              	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </thead>
           </table>
          </div>
      </div>
    </div>
  </div>
</main>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

  <script>

  	$(document).ready(function() {

	    datatablesOperasional($('#dokelkt'), '<?php echo e(route('api.kt.dokel', $tahun)); ?>', 'kt');

  	});
  	
  </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('intern.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>