1. 
Tipe Dokumen Harus Berupa Excel!
2. 
File laporan harus dipisahkan per bulan & sesuai jenis permohonan masing2 (domas, dokel, ekspor, impor) 
-> kaintanya dengan rule nomor 6
3.
File Laporan Harus asli dari iqfast tanpa perubahan apapun
jika file mengalami perubahan atau tidak sesuai maka file akan dianggap bukan hasil export dari iqfast
4. 
Wilker si user pengupload harus sesuai dengan wilker pada dokumen yang diupload
->excel row ke 1
5. 
Jenis karantina si user (kh/ kt) harus sesuai dengan jenis karantina pada dokumen yang 
diupload
6.
jenis permohonan (domas, dokel, ekspor, impor) harus sesuai dengan jenis permohonan
pada masing2 halaman (misalnya si user sedang berada pada halaman upload dokel tetapi dokumen yang di upload ternyata domas maka si user akan mendapatkan pesan error)
