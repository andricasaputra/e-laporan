<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    <div class="row text-center">
                        <div class="col-md-6">  
                            <a href="<?php echo e(route('page.domas')); ?>">
                                <i class="fa fa-upload fa-4x"></i> Domestik Masuk
                            </a>
                        </div>
                        <div class="col-md-6">
                            <a href="<?php echo e(route('page.dokel')); ?>">
                                <i class="fa fa-upload fa-4x"></i> Domestik Keluar
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>