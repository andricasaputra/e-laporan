<?php $__env->startSection('link'); ?>

<link href="<?php echo e(asset('css/ikm.css')); ?>" rel="stylesheet">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <?php echo $__env->make('inc.ikm_navbar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  
  <!--==========================
    Intro Section
  ============================-->
  <section id="about" class="wow fadeInUp">
  <!-- Set up your HTML -->
	<div class="container mb-5">
    <div id="result" class="text-center"></div>
    <div class="col-12 text-center" style="margin-bottom: 3%">
      <h5 class="judul"><?php echo e($is_open->keterangan); ?></h5>
      <p class="judul"><?php echo e($is_open->start_date); ?> s/d <?php echo e($is_open->end_date); ?></p>
      <hr>
    </div>
		<form action="<?php echo e(route('ikm.store')); ?>" method="POST">
      <?php echo csrf_field(); ?>
			<div class="form">
				<p class="mb-3">A. Data responden</p>
        <hr>
            <div class="form-group">
              <select class="form-control" name="jenis_layanan" required="required">
                <option disabled selected value="">- Jenis Layanan -</option>
                <?php $__currentLoopData = $layanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                  <option value="<?php echo e($l->id); ?>"><?php echo e($l->jenis_layanan); ?></option>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
            <div class="form-row">
              <div class="form-group col-md-6">
                <select class="form-control" name="jenis_kelamin" required="required">
                  <option disabled selected value="">- Jenis Kelamin -</option>
                  <option value="1">Laki-laki</option>
                  <option value="2">Perempuan</option>
                </select>
              </div>
              <div class="form-group col-md-6">
                <select class="form-control" name="umur" required="required">
                  <option disabled selected value="">- Umur -</option>
                  <?php $__currentLoopData = $umur; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <option value="<?php echo e($u->id); ?>"><?php echo e($u->umur); ?></option>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>
            <div class="form-row">
              <div class="form-group col-md-6">
                <select class="form-control" name="pendidikan" required="required">
                  <option disabled selected value="">- Pendidikan Terakhir -</option>
                  <?php $__currentLoopData = $pendidikan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <option value="<?php echo e($p->id); ?>"><?php echo e($p->pendidikan); ?></option>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              <div class="form-group col-md-6">
                <select class="form-control" name="pekerjaan" required>
	                <option disabled selected value="">- Pekerjaan -</option>
                    <?php $__currentLoopData = $pekerjaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                      <option value="<?php echo e($p->id); ?>"><?php echo e($p->pekerjaan); ?></option>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>
       		</div>
          
       	<p class="mt-3 mb-3">B. Pendapat responden tentang pelayanan</p>
        <hr>
       	<div class="col-12">
          <input type="hidden" name="ikm_id" value="<?php echo e($is_open->id); ?>">
	         <ol>
				  		<?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				  		<div class="form-group mt-3 mb-3">
					  		<div class="mb-3" style="text-align: left; margin-top: 20px">
					  			<h5><li><?php echo e($question->question); ?></li></h5>
					  			<?php $__currentLoopData = $question->answer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					  				<div class="form-check" style="margin-top: 20px;margin-bottom: 20px">
									    <div class="radio">
  										  <label>
                          <input type="radio" value="<?php echo e($answer->id); ?>" name="<?php echo e($question->id); ?>[]" required>
                          <?php echo e($answer->answer); ?>

                        </label>

										  </div>
									</div>
					  			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					  		</div>	
					  	</div>
              <hr>
					  	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				  	</ol>
			  	</div> 
          <div class="text-center"><button type="submit" class="send_ikm">Kirim</button></div>
        </form>
        <hr>
	</div>

  </section><!-- #intro -->

  <main>
  <!--==========================
      Contact Section
    ============================-->
    <section id="contact">
      <div class="container">
        <div class="section-header">
          <h2>Kontak kami</h2>
          <p>Jika anda memiliki keluhan, saran atau masukan atas pelayanan yang kami berikan,
            silahkan hubungi kami melalui call center dibawah ini. Kami informasikan bahwa petugas kami
            <b>tidak</b> menerima <b>suap</b> dan <b>gratifikasi</b> dalam bentuk apapun!
          </p>
        </div>

        <div class="row contact-info">

          <div class="col-md-4">
            <div class="contact-address">
              <i class="ion-ios-location-outline"></i>
              <h3>Alamat</h3>
              <address>Jln. Pelabuhan Badas No. 01 Sumbawa Besar</address>
            </div>
          </div>

          <div class="col-md-4">
            <div class="contact-phone">
              <i class="ion-ios-telephone-outline"></i>
              <h3>Telepon</h3>
              <p><a href="tel:+155895548855">(0371) 2629152</a></p>
            </div>
          </div>

          <div class="col-md-4">
            <div class="contact-email">
              <i class="ion-ios-email-outline"></i>
              <h3>Email</h3>
              <p><a href="#">humasskpsumbawa@gmail.com</a></p>
            </div>
          </div>

        </div>
      </div>

    </section><!-- #contact -->

  </main>

<?php $__env->stopSection(); ?>	




<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>