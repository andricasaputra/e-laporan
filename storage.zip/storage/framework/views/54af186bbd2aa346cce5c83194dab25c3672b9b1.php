<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('barside.title', 'IKM Sumbawa'); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-12 col-sm-12 col-xs-12">
	<div class="page-title">
	  <div class="title_left">
	    <h3>Hasil Survey IKM</h3>
	  </div>
	</div>
</div>

<div class="clearfix"></div>

<div class="col-md-12 col-sm-12 col-xs-12">
	<div class="x_panel">
	  <div class="x_content">
      <div class="col-md-1">
          <div class="form-group">
            <label>Pilih Tahun</label>
            <select class="form-control" name="year" id="year">
             
              <?php if(last(request()->segments()) == 'home'): ?>

                <option value="<?php echo e(date('Y')); ?>" selected><?php echo e(date('Y')); ?></option>

              <?php endif; ?>

              <?php for($i = date('Y') - 3; $i < date('Y') + 2 ; $i++): ?>

                <?php if(last(request()->segments()) == $i): ?>
        
                  <option value="<?php echo e($i); ?>" selected><?php echo e($i); ?></option>

                <?php else: ?>

                  <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                  
                <?php endif; ?>

              <?php endfor; ?>

            </select>
            
          </div>
      </div>
	    <table id="adminHomeIkm" class="table table-striped table-bordered text-center" width="100%">
	      <thead>
	        <tr>
	          <th>No</th>
            <th>Periode</th>
	          <th>Responden ID</th>
	          <th>Layanan</th>
	          <th>Jenis Kelamin</th>
	          <th>Umur</th>
	          <th>Pendidikan</th>
	          <th>Pekerjaan</th>
            <th>Waktu Survey</th>
            <th>Nilai Rata-rata</th>
	          <th>Action</th>
	        </tr>
	      </thead>
	    </table>
	  </div>
	</div>
</div>

<!-- Modal Delete -->
<div class="modal fade" id="modalDeleteIkm" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel"></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body text-center">
      	<h3>Apakah Anda Yakin Ingin Meghapus Data Ini?</h3><br>
        <form action="<?php echo e(route('intern.ikm.home.destroy', 'delete')); ?>" method="post">

	  		<?php echo csrf_field(); ?>
        	<?php echo method_field('DELETE'); ?>

        	<input type="hidden" name="id" id="ikmId">
        	
        	<input type="submit" name="delete" value="Ya" class="btn btn-primary">

        	<button type="button" class="btn btn-success" data-dismiss="modal">Tidak</button>
	  	</form>
      </div>
      <div class="modal-footer">
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

  <script>
    

    $(document).ready(function() {

      $('#year').on('change', function(){

        let year = $(this).val();

        window.location = '<?php echo e(route('intern.ikm.home.index')); ?>/' + year;

      });

    	let url = '<?php echo e(route('api.ikm', $tahun)); ?>';
    	let data = [

	    	{ "data" : "DT_Row_Index", orderable: false, searchable: false},
          { "data" : "ikm[0].keterangan" },
	        { "data" : "id" },
	        { "data" : "layanan.jenis_layanan" },
	        { "data" : "jenis_kelamin" },
	        { "data" : "umur.umur" },
	        { "data" : "pekerjaan.pekerjaan" },
	        { "data" : "pendidikan.pendidikan" },
          { "data" : "created_at" },
          { "data" : ""},
	        { "data" : "action" , orderable: false, searchable: false}

		]

	    $('#adminHomeIkm').DataTable({

            "processing": true,
            "serverSide": true,
            "ajax":{
               "url": url,
               "dataType": "JSON"
            },
            "columns": data,
			"columnDefs": [{
			    "defaultContent": "-",
			    "targets": "_all"
			}]

        });

  	});

  	$(document).on('click', '#deleteIkm', function(e){

        e.preventDefault();
        let id = $( this ).data( 'id' );

        $('#modalDeleteIkm').modal('show');

        let idInForm = $("#modalDeleteIkm #ikmId").val(id);

    });
  </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('intern.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>