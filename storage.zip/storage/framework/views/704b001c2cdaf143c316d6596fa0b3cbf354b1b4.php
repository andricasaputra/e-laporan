<?php $__env->startSection('title', 'E-IKM | Setting Pertanyaan'); ?>

<?php $__env->startSection('barside.title', 'IKM Sumbawa'); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-12 col-sm-12 col-xs-12">
	<div class="page-title">
	  <div class="title_left">
	    <h3>Pertanyaan IKM</h3>
	  </div>
	</div>
</div>

<div class="clearfix"></div>

<div class="col-md-12 col-sm-12 col-xs-12">
	<div class="x_panel">
	  <div class="x_title">
	    <a href="<?php echo e(route('intern.ikm.question.create')); ?>" class="btn btn-primary"><i class="fa fa-plus"></i> Tambah Pertanyaan</a>
	    <ul class="nav navbar-right">
	      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
	      </li>
	    </ul>
	    <div class="clearfix"></div>
	  </div>
	  <div class="x_content">
	    <table class="table table-striped table-bordered text-center datatable" width="100%">
	      <thead>
	        <tr>
	          <th>No</th>
	          <th>Pertanyaan</th>
	          <th>Action</th>
	        </tr>
	      </thead>
	      <tbody>
	      	<?php $no = 1 ?>
	      	<?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	      		<tr>
		      		<td><?php echo e($no++); ?></td>
		      		<td><?php echo e($question->question); ?></td>
		      		<td>
		      			<a href="<?php echo e(route('intern.ikm.question.edit', $question->id)); ?>" class="btn btn-success btn-xs"> Edit</a>
		      			<br>
		      			<a href="<?php echo e(route('intern.ikm.question.show', $question->id)); ?>" class="btn btn-warning btn-xs"> Detail Pertanyaan</a>
		      			<form action="<?php echo e(route('intern.ikm.question.destroy', $question->id)); ?>" method="POST">
		      				<?php echo csrf_field(); ?>
	      					<?php echo method_field('DELETE'); ?>
			      			<button type="submit" class="btn btn-danger btn-xs" onclick=" return confirm('Apakah Anda Yakin Ingin Menghapus File Ini?')">
	      						Delete
	      					</button>
		      			</form>
		      		</td>
	      		</tr>
	      	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	      </tbody>
	    </table>
	  </div>
	</div>
</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('intern.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>