<?php $__env->startSection('title', 'Ubah Jawaban IKM'); ?>

<?php $__env->startSection('barside.title', 'IKM Sumbawa'); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-12 col-sm-12 col-xs-12">
	<div class="page-title">
	  <div class="title_left">
	    <h3>Edit Jawaban Responden IKM</h3>
	  </div>
	</div>
</div>

<div class="clearfix"></div>

<div class="col-md-12 col-sm-12 col-xs-12">
	<div class="x_panel">
	  <div class="x_title">
	    <a href="<?php echo e(route('intern.ikm.home.index')); ?>" class="btn btn-primary"><i class="fa fa-arrow-left"></i> Kembali</a>
	    <ul class="nav navbar-right panel_toolbox">
	      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
	      </li>
	    </ul>
	    <div class="clearfix"></div>
	  </div>
	  <div class="x_content">

	  	<form action="<?php echo e(route('intern.ikm.home.update', $responden->id)); ?>" method="post" enctype="multipart/form-data">

	  		<?php echo csrf_field(); ?>
	  		<?php echo method_field('PUT'); ?>

	  		<?php $no = 1  ?>

	  		<input type="hidden" name="responden_id"  value="<?php echo e($responden->id); ?>">
	  		<?php for($i = 0; $i < count($responden->question); $i++): ?>

	  			<h4><?php echo e($no++); ?> Pertanyaan : <?php echo e($responden->question[$i]->question); ?></h4>

	  			<div class="form-group">

		  			<label for="jawaban">Jawaban</label>
	  				<select name="<?php echo e($responden->id); ?>[]" class="form-control">
		  				<option value="<?php echo e($responden->answer[$i]->id); ?>"><?php echo e($responden->answer[$i]->answer); ?></option>
		  				<?php $__currentLoopData = $jawaban; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		  					<option value="<?php echo e($j->id); ?>"><?php echo e($j->answer); ?></option>
		  				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	  				</select>

		  		</div>

	  		<?php endfor; ?>
		  	<br/>
	  		<div class="pull-right">
	  			<input type="submit" name="submit" value="Simpan" class="btn btn-warning">
	  		</div>

	  	</form>

	  </div>
	</div>
</div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('intern.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>