<div class="mdc-list-item mdc-drawer-item"  data-toggle="expansionPanel" target-panel="ui-sub-menu-kt-show">
  <a class="mdc-drawer-link" href="#">
    <i class="material-icons mdc-list-item__start-detail mdc-drawer-item-icon" aria-hidden="true">desktop_mac</i>
    Data Operasional KT
    <i class="mdc-drawer-arrow material-icons">arrow_drop_down</i>
  </a>
  <div class="mdc-expansion-panel" id="ui-sub-menu-kt-show">
    <nav class="mdc-list mdc-drawer-submenu">
      <div class="mdc-list-item mdc-drawer-item">
        <a class="mdc-drawer-link" href="<?php echo e(route('kt.view.page.ekspor', date('Y'))); ?>">
          Ekspor
        </a>
      </div>
      <div class="mdc-list-item mdc-drawer-item">
        <a class="mdc-drawer-link"href="<?php echo e(route('kt.view.page.impor', date('Y'))); ?>">
          Impor
        </a>
      </div>
      <div class="mdc-list-item mdc-drawer-item">
        <a class="mdc-drawer-link" href="<?php echo e(route('kt.view.page.domas', date('Y'))); ?>">
          Domestik Masuk
        </a>
      </div>
      <div class="mdc-list-item mdc-drawer-item">
        <a class="mdc-drawer-link" href="<?php echo e(route('kt.view.page.dokel', date('Y'))); ?>">
          Domestik Keluar
        </a>
      </div>
    </nav>
  </div>
</div>
<div class="mdc-list-item mdc-drawer-item" data-toggle="expansionPanel" target-panel="ui-sub-menu-kt">
  <a class="mdc-drawer-link" href="#">
    <i class="material-icons mdc-list-item__start-detail mdc-drawer-item-icon" aria-hidden="true">backup</i>
    Upload KT
    <i class="mdc-drawer-arrow material-icons">arrow_drop_down</i>
  </a>
  <div class="mdc-expansion-panel" id="ui-sub-menu-kt">
    <nav class="mdc-list mdc-drawer-submenu">
      <div class="mdc-list-item mdc-drawer-item">
        <a class="mdc-drawer-link" href="<?php echo e(route('kt.upload.page.ekspor')); ?>">
          Ekspor
        </a>
      </div>
      <div class="mdc-list-item mdc-drawer-item">
        <a class="mdc-drawer-link" href="<?php echo e(route('kt.upload.page.impor')); ?>">
          Impor
        </a>
      </div>
      <div class="mdc-list-item mdc-drawer-item">
        <a class="mdc-drawer-link" href="<?php echo e(route('kt.upload.page.domas')); ?>">
          Domestik Masuk
        </a>
      </div>
      <div class="mdc-list-item mdc-drawer-item">
        <a class="mdc-drawer-link" href="<?php echo e(route('kt.upload.page.dokel')); ?>">
          Domestik Keluar
        </a>
      </div>
    </nav>
  </div>
</div>

