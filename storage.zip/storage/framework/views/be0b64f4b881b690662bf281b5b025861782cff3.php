<?php $__env->startSection('title', 'Home Operasional - Halaman Utama'); ?>

<?php $__env->startSection('content'); ?>

<style type="text/css">
  .card {
    width: 100%;
    margin-bottom: 5%;
  }
</style>

<main class="content-wrapper">
    <div class="mdc-layout-grid">
      <div class="mdc-layout-grid__inner">
        <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-12">
          <div class="mdc-card">
            <div class="mdc-layout-grid__inner">
              <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-7">
                <section class="purchase__card_section">
                    Data Operasional Tahun <?php echo e($datas['tahun']); ?>

                </section>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="container-fluid">

      <div class="col">
        
        <div class="row mb-3">
          <div class="col-md-2 col-sm-12">
            <form action="<?php echo e(route('post.tahun.operasional.kt')); ?>" method="POST">
              <?php echo csrf_field(); ?>
              <div class="form-group">
                <label>Tahun</label>
                <select class="form-control" name="year">
                  <?php for($i = date('Y') - 3; $i < date('Y') + 2 ; $i++): ?>
              
                    <?php if($i == $datas['tahun']): ?>

                      <option value="<?php echo e($i); ?>" selected><?php echo e($i); ?></option>

                    <?php else: ?>

                      <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>

                    <?php endif; ?>

                  <?php endfor; ?>
                </select>
              </div>
              <button type="submit">Pilih</button>
            </form>
          </div>
        </div>

        <div class="row">
          <?php $__currentLoopData = $datas['kt']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-3">
              <div class="card">
                <div class="card-body">
                  <div class="row">
                    <div class="col-sm-12 card_body_welcome">
                        <h4 class="card-title"><?php echo e($key); ?></h4>
                        <small><i>Berdasarkan Sertifikasi</i></small>
                        <h5 class="card-text"><i>Frekuensi : <?php echo e($data['frekuensi']); ?></i></h5>
                        <a href="<?php echo e($data['link']); ?>" class="btn btn-success btn-xs">Detail</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
      </div>

    </div> 

</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('intern.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>