<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title><?php echo $__env->yieldContent('title', 'Survey Indeks Kepuasan Masyarakat'); ?></title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="survey-ikm" name="keywords">
  <meta content="survey-ikm-sumbawa" name="description">

  <!-- Favicons -->
  <link href="<?php echo e(asset('images/favicon-32x32.png')); ?>" rel="icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Raleway:300,400,500,700,800|Montserrat:300,400,700" rel="stylesheet">

  <!-- Bootstrap CSS File -->
  <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

  <!-- Libraries CSS Files -->
  <link href="<?php echo e(asset('font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('css/animate.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('css/ionicons.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('css/owl.carousel.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('css/magnific-popup.css')); ?>" rel="stylesheet">

  <!-- Main Stylesheet File -->
  <link href="<?php echo e(asset('css/reveal.css')); ?>" rel="stylesheet">

  <?php echo $__env->yieldContent('link'); ?>

</head>

<body id="body">

  <?php echo $__env->yieldContent('content'); ?>

  <!--==========================
    Footer
  ============================-->
  <footer id="footer">
    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong>Reveal</strong>. All Rights Reserved
      </div>
      <div class="credits">
        Stasiun Karatina Pertanian Kelas I Sumbawa Besar
      </div>
    </div>
  </footer><!-- #footer -->

  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>

  <!-- JavaScript Libraries -->
  <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
  <script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>
  <script src="<?php echo e(asset('js/easing.min.js')); ?>"></script>
  <script src="<?php echo e(asset('js/hoverIntent.js')); ?>"></script>
  <script src="<?php echo e(asset('js/superfish.min.js')); ?>"></script>
  <script src="<?php echo e(asset('js/wow.min.js')); ?>"></script>
  <script src="<?php echo e(asset('js/owl.carousel.min.js')); ?>"></script>
  <script src="<?php echo e(asset('js/magnific-popup.min.js')); ?>"></script>
  <script src="<?php echo e(asset('js/sticky.js')); ?>"></script>

  <!-- Contact Form JavaScript File -->
  <script src="<?php echo e(asset('js/contactform.js')); ?>"></script>

  <!-- Template Main Javascript File -->
  <script src="<?php echo e(asset('js/reveal.js')); ?>"></script>

  <?php echo $__env->yieldContent('script'); ?>

</body>
</html>