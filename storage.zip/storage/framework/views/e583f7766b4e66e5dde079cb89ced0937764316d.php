<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <!-- CSRF Token -->
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <title><?php echo $__env->yieldContent('title', config('app.name')); ?></title>
  <link rel="icon" href="<?php echo e(asset('images/favicon-32x32.png')); ?>" type="image/png" sizes="32x32">
  <link rel="stylesheet" href="<?php echo e(asset('css/materialdesignicons.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('font-awesome/css/font-awesome.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/datatables.min.css')); ?>">
 
</head>

<body>
  <div class="body-wrapper">
    <!-- partial:../../partials/_sidebar.html -->
    <?php echo $__env->make('intern.inc.barside', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- partial -->
    <!-- partial:../../partials/_navbar.html -->
    <header class="mdc-toolbar mdc-elevation--z4 mdc-toolbar--fixed">
      <div class="mdc-toolbar__row">
        <section class="mdc-toolbar__section mdc-toolbar__section--align-start">
          <a href="#" class="menu-toggler material-icons mdc-toolbar__menu-icon">menu</a>
        </section>
        <section class="mdc-toolbar__section mdc-toolbar__section--align-end" role="toolbar">
          <div class="mdc-menu-anchor mr-1">
            <a href="#" class="mdc-toolbar__icon toggle mdc-ripple-surface" data-toggle="dropdown" toggle-dropdown="logout-menu" data-mdc-auto-init="MDCRipple">
              <i class="material-icons">more_vert</i>
            </a>
            <div class="mdc-simple-menu mdc-simple-menu--right" tabindex="-1" id="logout-menu">
                <ul class="mdc-simple-menu__items mdc-list" role="menu" aria-hidden="true">
                  <?php if(Auth::user()->role_id == 1): ?> 
                    <a href="<?php echo e(route('welcome.admin')); ?>">
                  <?php else: ?>
                    <a href="<?php echo e(route('welcome')); ?>">
                  <?php endif; ?>
                      
                      <li class="mdc-list-item" role="menuitem" tabindex="0">
                        <i class="material-icons mdc-theme--primary mr-1">settings</i>
                        Go To Home
                      </li>
                      
                  </a>
                  
                  <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                    document.getElementById('logout-form').submit();">
                    <li class="mdc-list-item" role="menuitem" tabindex="0">
                      <i class="material-icons mdc-theme--primary mr-1">power_settings_new</i>Logout
                    </li>
                  </a>
                </ul>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>
            </div>
          </div>
        </section>
      </div>
    </header>
    <!-- partial -->

    <div class="page-wrapper mdc-toolbar-fixed-adjust">

      <?php echo $__env->yieldContent('content'); ?>
  
    </div>

  </div>

  <!-- body wrapper -->

  <script src="<?php echo e(asset('js/material-components-web.min.js')); ?>"></script>
  <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
  <script src="<?php echo e(asset('js/Chart.min.js')); ?>"></script>
  <script src="<?php echo e(asset('js/progressbar.min.js')); ?>"></script>
  <script src="<?php echo e(asset('js/misc.js')); ?>"></script>
  <script src="<?php echo e(asset('js/material.js')); ?>"></script>
  <script src="<?php echo e(asset('js/dashboard.js')); ?>"></script>
  <script src="<?php echo e(asset('js/datatables.min.js')); ?>"></script>
  <script src="<?php echo e(asset('js/datatables_operasional.js')); ?>"></script>
  
  <?php echo $__env->yieldContent('custom_scripts'); ?>

  <script>
    window.setTimeout(function() {
        $(".alert-success").fadeTo(500, 0).slideUp(500, function() {
            $(this).hide();
        });
    }, 5000);
  </script>
  <!-- End custom js for this page-->
</body>

</html>